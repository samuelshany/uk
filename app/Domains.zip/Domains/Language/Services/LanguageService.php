<?php

namespace App\Domains\Language\Services;


use App\Domains\Language\Interfaces\LanguageRepositoryInterface;

class LanguageService
{

}

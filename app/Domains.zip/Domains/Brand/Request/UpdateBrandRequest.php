<?php

namespace App\Domains\Brand\Request;

use Illuminate\Foundation\Http\FormRequest;

class UpdateBrandRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'name' => "required|regex:/^[a-zA-Z0-9ء-ي,\'\-,\s]*$/|max:50",
            'code' => 'nullable|unique:brands,code|max:10',
            'description' => 'max:200',
        ];
    }
    public function messages()
    {
        return [
            'name.regex' => __('The name contins invalid letter'),
            'code.unique' => __('The code must be unique'),
        ];
    }
}

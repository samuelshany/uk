<?php

namespace App\Domains\Module\Repositories;

use App\Domains\Module\Interfaces\ModuleRepositoryInterface;
use App\Domains\Module\Models\Module;
use Illuminate\Database\Eloquent\Collection;

class ModuleMySqlRepository implements ModuleRepositoryInterface
{
}
